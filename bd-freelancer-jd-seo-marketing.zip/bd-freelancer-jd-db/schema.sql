
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name_en TEXT,
  name_bn TEXT,
  email TEXT UNIQUE,
  password_hash TEXT,
  role TEXT CHECK (role IN ('freelancer','client','admin')),
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS freelancer_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  skills JSONB DEFAULT '[]'::jsonb,
  rating NUMERIC(2,1),
  portfolio_url TEXT,
  bio_en TEXT,
  bio_bn TEXT
);

CREATE TABLE IF NOT EXISTS client_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  company_name TEXT,
  desc_en TEXT,
  desc_bn TEXT
);

CREATE TABLE IF NOT EXISTS job_posts (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  title_en TEXT,
  title_bn TEXT,
  desc_en TEXT,
  desc_bn TEXT,
  budget NUMERIC,
  status TEXT DEFAULT 'open',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bids (
  id SERIAL PRIMARY KEY,
  job_id INTEGER REFERENCES job_posts(id) ON DELETE CASCADE,
  freelancer_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  amount NUMERIC,
  proposal_en TEXT,
  proposal_bn TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  job_id INTEGER REFERENCES job_posts(id) ON DELETE SET NULL,
  freelancer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  client_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  amount NUMERIC,
  status TEXT DEFAULT 'held',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  job_id INTEGER REFERENCES job_posts(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment_en TEXT,
  comment_bn TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  receiver_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  text_en TEXT,
  text_bn TEXT,
  created_at TIMESTAMP DEFAULT now()
);
