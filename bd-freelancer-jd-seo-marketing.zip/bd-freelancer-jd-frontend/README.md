
# BD FREELANCER JD — Frontend (React + Vite)
- Bilingual UI (English / বাংলা)
- Services directory includes official links.
## Run
```bash
npm install
npm run dev
```
