import React from 'react'
export default function Home(){
  return (
    <div style={{padding:24}}>
      <h1>BD FREELANCER JD — Bilingual Marketplace / দ্বিভাষিক মার্কেটপ্লেস</h1>
      <p>Find services & jobs locally / স্থানীয় সেবা ও কাজ খুঁজুন</p>
    </div>
  )
}