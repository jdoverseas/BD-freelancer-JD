import React, { useEffect, useState } from 'react'
import data from '../data/services.json'

export default function Services(){
  const [q,setQ] = useState('')
  const items = data.filter(s => (s.en+s.bn).toLowerCase().includes(q.toLowerCase()))
  return (
    <div style={{padding:24}}>
      <h2>Government, Public & Private Services / সরকারি, জনসেবা ও বেসরকারি সেবা</h2>
      <input placeholder="Search / খুঁজুন" value={q} onChange={e=>setQ(e.target.value)} style={{padding:8, width:'100%',maxWidth:420,margin:'12px 0'}}/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:12}}>
        {items.map(s => (
          <div key={s.id} style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
            <div style={{fontWeight:700}}>{s.en} / {s.bn}</div>
            <div style={{fontSize:12,opacity:.7}}>{s.category}</div>
            <div style={{marginTop:8, display:'flex', flexDirection:'column', gap:6}}>
              {s.links?.map((href,i)=>(
                <a target="_blank" href={href} key={i} rel="noreferrer">{href}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}