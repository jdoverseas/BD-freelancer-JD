import React from 'react'
import { Helmet, HelmetProvider } from 'react-helmet-async'

export default function SEO({ title, description, image, url }){
  const siteTitle = title ? `${title} • BD FREELANCER JD` : 'BD FREELANCER JD'
  const desc = description || 'BD FREELANCER JD - Find local services and freelancers (বাংলা/English).'
  const metaImage = image || `${window.location.origin}/og-image.png`
  const pageUrl = url || window.location.href
  return (
    <HelmetProvider>
      <Helmet>
        <title>{siteTitle}</title>
        <meta name="description" content={desc} />
        <meta name="robots" content="index, follow" />
        <meta property="og:title" content={siteTitle} />
        <meta property="og:description" content={desc} />
        <meta property="og:image" content={metaImage} />
        <meta property="og:url" content={pageUrl} />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context":"https://schema.org",
            "@type":"WebSite",
            "name":"BD FREELANCER JD",
            "url": window.location.origin,
            "potentialAction": { "@type":"SearchAction", "target": `${window.location.origin}/?q={search_term_string}`, "query-input":"required name=search_term_string" }
          })}
        </script>
      </Helmet>
    </HelmetProvider>
  )
}