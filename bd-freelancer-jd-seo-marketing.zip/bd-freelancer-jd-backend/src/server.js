import express from 'express'
import cors from 'cors'
import fs from 'fs'
import path from 'path'
import dotenv from 'dotenv'
dotenv.config()

const app = express()
app.use(cors())
app.use(express.json())

app.get('/api/health', (req,res)=> res.json({ok:true, message:"BD FREELANCER JD API / বিডি ফ্রীল্যান্সার জেডি এপিআই"}))

app.get('/api/services', (req,res)=>{
  const p = path.join(process.cwd(),'..','bd-freelancer-jd-frontend','src','data','services.json')
  const raw = fs.readFileSync(p,'utf-8')
  res.setHeader('Content-Type','application/json; charset=utf-8')
  res.send(raw)
})

const port = process.env.PORT || 4000
app.listen(port, ()=> console.log('API listening on '+port))
