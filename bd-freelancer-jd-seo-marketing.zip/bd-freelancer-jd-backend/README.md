# BD FREELANCER JD — Backend (Express)

Run: `npm install && npm run dev`
