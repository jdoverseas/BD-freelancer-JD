
# BD FREELANCER JD — Monorepo (Frontend + Backend + DB)
- Frontend: React + Vite (bilingual UI), see `bd-freelancer-jd-frontend`
- Backend: Express API serving services list and placeholder routes
- DB: PostgreSQL schema (bilingual-friendly)
## Run locally
See each package README. Order: start DB (optional), backend, then frontend.
## GitHub
Initialize each folder as its own repository or push this root as mono-repo.
